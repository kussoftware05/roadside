
const baseUrl = 'https://matrika.com.omaharoadsideassistance.org/api/front_api.php';
export const apiUrl = baseUrl;
