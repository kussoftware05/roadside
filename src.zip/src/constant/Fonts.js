export const FONTS = {
    ExtraBold : 'Inter-ExtraBold',
    SemiBold : 'Inter-SemiBold',
    Bold : 'Inter-Bold',
    Medium : 'Inter-Medium',
    Regular : 'Inter-Regular',
}